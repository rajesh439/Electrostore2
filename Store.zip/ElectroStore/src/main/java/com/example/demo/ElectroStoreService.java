package com.example.demo;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;




@Service
public class ElectroStoreService {
	@Autowired
	JdbcTemplate jdbctemplate;
	
	public List<ElectroStore> usernameandpassword(){
		String sql2="select username,password from task1";
		RowMapper<ElectroStore> rm = new RowMapper<ElectroStore>() {
            @Override
            public ElectroStore mapRow(ResultSet rs, int i) throws SQLException {
            	ElectroStore res1 = new ElectroStore();
        
          
            res1.setUsername(rs.getString(1));
            res1.setPassword(rs.getString(2));
           
           
          
          
                return res1;
                
            }
        };
      return  jdbctemplate.query(sql2, rm);
		
	}
		
	}


